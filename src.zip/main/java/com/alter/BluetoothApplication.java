package com.alter;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class BluetoothApplication extends Application {

    BluetoothService btService = null;
    Intent btIntent;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    static BluetoothApplication instance;

    boolean isDisconnected = false;
    String TAG = this.getClass().getSimpleName() + ":::::";

    @Override
    public void onCreate() {
        super.onCreate();
        btIntent = new Intent(this, BluetoothService.class);
        sharedPreferences = getSharedPreferences("pref", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        instance = this;
        startService();
        Log.i(TAG, "onCreate");
    }

    public static BluetoothApplication getInstance() {
        return instance;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Log.i(TAG, "onConfigurationChanged");
    }

    public void startService() {
        startService(btIntent);
        bindService(btIntent, btServiceConnection, BIND_AUTO_CREATE);
    }

    public void stopService() {
        unbindService(btServiceConnection);
        stopService(btIntent);
    }

    public BluetoothService getBTService() {
        return btService;
    }

    ServiceConnection btServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            BluetoothService.LocalBinder binder = (BluetoothService.LocalBinder)service;
            btService = binder.getServerInstance();
            Log.i(TAG, "Bind");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.i(TAG, "Unbind");
            btService = null;
        }
    };

    public void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    public void setSharedData(String key, String data) {
        Log.i(TAG, String.format("SharedDataSet key: %s, data: %s", key, data));
        editor.putString(key, data);
        editor.commit();
    }

    public void setSharedData(String key, boolean data) {
        Log.i(TAG, String.format("SharedDataSet key: %s, data: %b", key, data));
        editor.putBoolean(key, data);
        editor.commit();
    }

    public void setSharedData(String key, int data) {
        Log.i(TAG, String.format("SharedDataSet key: %s, data: %d", key, data));
        editor.putInt(key, data);
        editor.commit();
    }

    public String getSharedData(String key, String defaultValue) {
        return sharedPreferences.getString(key, defaultValue);
    }

    public boolean getSharedData(String key, boolean defaultValue) {
        return sharedPreferences.getBoolean(key, defaultValue);
    }

    public int getSharedData(String key, int defaultValue) {
        return sharedPreferences.getInt(key, defaultValue);
    }
}
