package com.alter;

import android.Manifest;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener{

    DrawerLayout layout_drawer;
    ListView list_drawer;
    ImageView img_drawer, img_weather;
    TextView text_hello, text_location, text_updateTime, text_weather, text_temp, text_temps, text_connectDevice;

    DrawerMenuAdapter drawerAdapter;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    Handler h = null, h2 = null;

    String[] drawer_Array = {"My Umbrella", "Lost Alert", "LED", "Edit Location", "Seoul", "About Kingsman"};
    String[] weathers = {"토네이도", "열대 뇌우", "허리케인", "심각한 뇌우", "폭풍우", "진눈깨비", "진눈깨비", "진눈깨비", "진눈깨비", "진눈깨비", "얼어붙은 비", "소나기", "소나기", "눈보라", "눈비", "눈보라", "눈", "우박", "진눈깨비", "황사", "안개가 낀", "흐릿함", "흐릿함", "돌풍", "바람부는", "추운", "흐림", "대체로 흐림(낮)", "대체로 흐림(저녁)", "부분적으로 흐림(낮)", "부분적으로 흐림(저녁)", "맑음(저녁)", "화창함", "살짝 맑음(저녁)", "살짝 맑음(낮)", "눈을 동반한 우박", "더움", "고립형 뇌우", "뇌우", "뇌우", "산발적 소나기", "폭설", "산발적 폭설", "폭설", "부분 흐림", "소낙비", "소낙눈", "산발적 뇌우", "날씨정보없음"};
    String cityData, userData, krWeather;
    int PERMISSION = 10;

    BluetoothService btService;
    BluetoothApplication BT;

    String TAG = this.getClass().getSimpleName() + ":::::";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BT = (BluetoothApplication)getApplicationContext();

        layout_drawer = findViewById(R.id.layout_drawer);
        list_drawer = findViewById(R.id.list_drawer);
        img_drawer = findViewById(R.id.img_drawer);
        img_weather = findViewById(R.id.img_weather);
        text_hello = findViewById(R.id.text_Hello);
        text_location = findViewById(R.id.text_Location);
        text_updateTime = findViewById(R.id.text_UpdateTime);
        text_weather = findViewById(R.id.text_weather);
        text_temp = findViewById(R.id.text_temp);
        text_temps = findViewById(R.id.text_temps);
        text_connectDevice = findViewById(R.id.text_connectDevice);

        sharedPreferences = getSharedPreferences("pref", MODE_PRIVATE);
        editor = sharedPreferences.edit();

        drawerAdapter = new DrawerMenuAdapter(sharedPreferences, editor, BT);

        list_drawer.setAdapter(drawerAdapter);
        list_drawer.setOnItemClickListener(this);
        img_drawer.setOnClickListener(this);
        cityData = sharedPreferences.getString("city", "도시");
        text_location.setText(cityData);

        if (cityData.equals("도시")) {
            startActivity(new Intent(this, EditLocationActivity.class));
            finish();
        } else {
            getWeather();
            makeDrawerMenu();
            requestPermission();
            refreshData();
        }
    }

    public void refreshData() {
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String deviceStatus;
                        if(btService.isConnected == true) {
                            deviceStatus = "connected";
                        } else {
                            deviceStatus = "disconnected";
                        }
                        userData = sharedPreferences.getString("lastConnected", "NULL");
                        text_connectDevice.setText(String.format("%s is %s", userData, deviceStatus));
                        text_hello.setText(String.format("%s님 안녕하세요\n오늘 %s은(는)\n%s", userData, cityData, krWeather));
                    }
                });
            }
        }, 1000, 1000);
    }

    public void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_PHONE_STATE}, PERMISSION);
    }

    public void deviceConnect() {
        final String lastMAC = sharedPreferences.getString("lastAddr", "NULL");
        if(btService != null) {
            if (!lastMAC.equals("NULL")) {
                if (sharedPreferences.getBoolean("checkStatus", false) && btService.isConnected == false) {
                    h = new Handler() {
                        public void handleMessage(Message msg) {
                            Log.i(TAG, "trying to connect: " + lastMAC);
                            try {
                                btService.connectDevice(lastMAC);
                                h.removeMessages(0);
                            } catch (NullPointerException e) {
                                h.sendEmptyMessageDelayed(0, 500);
                            }
                        }
                    };
                    h.sendEmptyMessage(0);
                }
                if(!sharedPreferences.getBoolean("checkStatus", false)) {
                }
            }
        }
    }

    public void makeDrawerMenu() {
        for(int i=0;i<drawer_Array.length;i++) {
            if (i == 1 || i == 2) {
                drawerAdapter.addItem(drawer_Array[i], "sw");
            } else if(i == 4) {
                drawerAdapter.addItem(sharedPreferences.getString("city", "도시이름"), "gps");
            } else {
                drawerAdapter.addItem(drawer_Array[i], "");
            }
        }
        h2 = new Handler() {
            public void handleMessage(Message msg) {
                if(btService == null) {
                    btService = BT.getBTService();
                    h2.sendEmptyMessageDelayed(0, 500);
                    deviceConnect();
                } else {
                    h2.removeMessages(0);
                }
            }
        };
        h2.sendEmptyMessage(0);
    }

    public void getWeather() {
        try {
            JSONObject jsonArray = new JSONObject(new GETWeatherTask().execute(sharedPreferences.getString("lat", "00"), sharedPreferences.getString("lon", "00")).get()).getJSONObject("query").getJSONObject("results").getJSONObject("channel");
            String[] updateTime = (jsonArray.getString("lastBuildDate")).split(" ");
            JSONObject todayWeather = (jsonArray.getJSONObject("item").getJSONArray("forecast").getJSONObject(0));
            JSONObject nowWeather = (jsonArray.getJSONObject("item").getJSONObject("condition"));
            String weatherCode = nowWeather.getString("code");
            if(Integer.parseInt(weatherCode) <= 47) {
                krWeather = weathers[Integer.parseInt(weatherCode)];
            } else {
                krWeather = "날씨정보 없음";
            }

            text_location.setText(cityData);
            text_updateTime.setText(String.format("LastUpdate %s %s %s", updateTime[4], updateTime[5], updateTime[6]));
            text_weather.setText(krWeather);
            text_temp.setText(String.format("%s℃", nowWeather.getString("temp")));
            text_temps.setText(String.format("↑%s℃  ↓%s℃", todayWeather.getString("high"), todayWeather.getString("low")));
            text_hello.setText(String.format("님 안녕하세요\n오늘 %s은(는)\n%s", cityData, krWeather));
            img_weather.setImageBitmap(Bitmap.createScaledBitmap(new GETWeatherIconTask(weatherCode).execute().get(), 100, 100, false));
            BT.setSharedData("weatherCode", weatherCode);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "날씨 데이터를 가져오는데 실패했습니다.\n인터넷 연결을 확인해주세요.", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.img_drawer:
                if(!layout_drawer.isDrawerOpen(Gravity.LEFT)) {
                    layout_drawer.openDrawer(Gravity.LEFT);
                }
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        switch (position) {
            case 0:
                startActivity(new Intent(this, UmbrellaActivity.class));
                layout_drawer.closeDrawer(Gravity.LEFT);
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                startActivity(new Intent(this, EditLocationActivity.class));
                layout_drawer.closeDrawer(Gravity.LEFT);
                finish();
                break;
            case 4:
                break;
            case 5:
                startActivity(new Intent(this, AboutActivity.class));
                layout_drawer.closeDrawer(Gravity.LEFT);
                break;
        }
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }
}
