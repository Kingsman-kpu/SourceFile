package com.alter;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class BluetoothService extends Service {

    BluetoothAdapter btAdapter;
    BluetoothGatt btConnection;
    BluetoothGattCharacteristic transfer;
    BluetoothApplication BT;

    UUID UART_UUID = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");

    boolean isConnected = false, isManualClose = false, isMove = false;
    String deviceaddr = "";
    String TAG = "BluetoothService:::::";
    String receiveData = "";

    IBinder bind = new LocalBinder();

    public BluetoothService() {
        BT = BluetoothApplication.getInstance();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return bind;
    }

    public class LocalBinder extends Binder {
        public BluetoothService getServerInstance() {
            return BluetoothService.this;
        }
    }

    public void connectDevice(String deviceAddress) {
        isManualClose = false;
        deviceaddr = deviceAddress;
        Log.i(TAG, "Connecting...");
        if(btAdapter == null) {
            btAdapter = BluetoothAdapter.getDefaultAdapter();
        }
        if(isConnected == true) {
            reconnectDevice(deviceaddr);
        }
        if(isConnected == false) {
            btConnection = btAdapter.getRemoteDevice(deviceAddress).connectGatt(this, false, gattCallback);
        }
    }

    public void disconnectDevice() {
        btConnection.disconnect();
        isManualClose = true;
        isConnected = false;
    }

    public void reconnectDevice(String deviceAddress) {
        deviceaddr = deviceAddress;
        btConnection.close();
        Handler i = new Handler();
        i.postDelayed(new Runnable() {
            @Override
            public void run() {
                btConnection = btAdapter.getRemoteDevice(deviceaddr).connectGatt(BluetoothService.this, false, gattCallback);
            }
        }, 1000);
    }


    protected BluetoothGattCallback gattCallback = new BluetoothGattCallback() {

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);
            switch (newState) {
                case BluetoothGatt.STATE_CONNECTED:
                    Log.i(TAG, "Connected");
                    gatt.discoverServices();
                    break;
                case BluetoothGatt.STATE_DISCONNECTED:
                    Log.i(TAG, "Disconnected");
                    if(!isManualClose && isConnected && BT.getSharedData("swStatus", false)) {
                        sendBroadcast(new Intent("com.alter.disconnected"));
                    } else if(!isManualClose && !isConnected) {
                        Handler toastHandler = new Handler(Looper.getMainLooper());
                        toastHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                BT.showToast("블루투스 연결에 실패했습니다.");
                            }
                        });
                    }
                    BT.setSharedData("checkStatus", false);
                    isConnected = false;
                    isMove = false;
                    break;
            }
        }

        @Override
        public void onServicesDiscovered(final BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);
            if(status == BluetoothGatt.GATT_SUCCESS) {
                Log.i(TAG, "Discovery Success");
            }
            isConnected = true;
            BluetoothGattService serv = gatt.getService(UART_UUID);
            try {
                transfer = serv.getCharacteristic(UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb"));
            } catch (Exception e) {
                Toast.makeText(BluetoothService.this, "블루투스 연결에 실패했습니다.", Toast.LENGTH_SHORT).show();
                isConnected = false;
                BT.setSharedData("checkStatus", false);
            }

            btConnection.setCharacteristicNotification(transfer, true);

        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);
            String receive = characteristic.getStringValue(0);
            Date date = new Date(System.currentTimeMillis());
            String dateFormat = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss . z").format(date);

            if(receive.contains("-")) {
//                receiveData += receive.replaceAll("-", "");
                receiveData += receive.split("-")[0];
                String[] data = receiveData.split("//");
                Log.i(TAG, receiveData);
                switch (data[0]) {
                    case "GPS":
                        BT.setSharedData("lastReceive", dateFormat);
                        BT.setSharedData("lastLocation", data[1]+"//"+data[2]);
                        break;
                    case "MOVE":
                        if(isMove == false) {
                            String weatherCode = "WC " + BT.getSharedData("weatherCode", "3200");
                            sendData(weatherCode);
                        }
                        isMove = true;
                        break;
                }
                receiveData = "";
            } else {
                receiveData += receive;
            }
        }

    };

    public void sendData(String msg) {
        if(msg != null && msg.length() > 0 && isConnected) {
            transfer.setValue(msg.getBytes(Charset.forName("UTF-8")));
            if(btConnection.writeCharacteristic(transfer)) {
                Log.i(TAG, "SEND: " + msg);
            } else {
                Log.e(TAG, "SEND Failed");
            }
        }
    }
}
