package com.alter;

public class UmbrellaListItem {

    String username;
    boolean status;

    public void setUsername(String username) {
        this.username = username;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getUsername() {
        return username;
    }

    public boolean getStatus() {
        return status;
    }

}
