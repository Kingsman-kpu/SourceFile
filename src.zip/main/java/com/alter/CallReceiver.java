package com.alter;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.util.Log;

public class CallReceiver extends BroadcastReceiver {

    String TAG = this.getClass().getSimpleName();

    BluetoothService btService;
    BluetoothApplication BT;

    @Override
    public void onReceive(Context context, Intent intent) {

        BT = (BluetoothApplication)context.getApplicationContext();
        btService = BT.getBTService();

        String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
        if(TelephonyManager.EXTRA_STATE_RINGING.equals(state)) {
            try {
                btService.sendData("Call true");
            } catch (Exception e) {

            }
            Log.i(TAG, "Call Receiver");
        } else {
            btService.sendData("Call false");
            Log.i(TAG, "Call Finished");
        }
    }
}
