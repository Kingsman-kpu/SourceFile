package com.alter;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class DrawerMenuAdapter extends BaseAdapter{

    ArrayList<DrawerMenuItem> arrayList = new ArrayList<>();
    SharedPreferences swPreferences;
    SharedPreferences.Editor swEditor;
    BluetoothApplication BT;
    BluetoothService btService;

    public DrawerMenuAdapter(SharedPreferences sharedPreferences, SharedPreferences.Editor editor, BluetoothApplication BT) {
        swPreferences = sharedPreferences;
        swEditor = editor;
        this.BT = BT;
    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return arrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        final Context context = parent.getContext();

        if(convertView == null) {
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.item_drawermenu, parent, false);
        }

        TextView title = convertView.findViewById(R.id.item_textTitle);
        final Switch onoff = convertView.findViewById(R.id.item_swOnOff);
        ImageView arrow = convertView.findViewById(R.id.item_imgArrowRight);
        ImageView gps = convertView.findViewById(R.id.item_imgGPS);

        final DrawerMenuItem item = arrayList.get(position);

        title.setText(item.getTitle());
        if(item.isUseSW) {
            onoff.setVisibility(View.VISIBLE);
            arrow.setVisibility(View.INVISIBLE);
            onoff.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(item.getTitle().equals("Lost Alert")) {
                        swEditor.putBoolean("swStatus", !swPreferences.getBoolean("swStatus", false));
                        swEditor.commit();
                    } else if(item.getTitle().equals("LED")){
                        try {
                            btService = BT.getBTService();
                            swEditor.putBoolean("ledStatus", !swPreferences.getBoolean("ledStatus", false));
                            swEditor.commit();
                            btService.sendData("LED " + swPreferences.getBoolean("ledStatus", false));
                        } catch (Exception e) {
                            Toast.makeText(context, "블루투스 연결을 확인해주세요", Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                        try {
                        } catch (NullPointerException e) {
                            return;
                        }
                    }
                }
            });
        } else if(item.isUseGPS){
            gps.setImageResource(R.drawable.ic_gps);
            onoff.setVisibility(View.INVISIBLE);
            arrow.setVisibility(View.INVISIBLE);
        } else {
            onoff.setVisibility(View.INVISIBLE);
            arrow.setVisibility(View.VISIBLE);
        }
        if(item.getTitle().equals("Lost Alert")) {
            onoff.setChecked(swPreferences.getBoolean("swStatus", false));
            Log.i("DrawerMenuAdapter:::::", swPreferences.getBoolean("swStatus", false) + "");
        } else if(item.getTitle().equals("LED")) {
            onoff.setChecked(swPreferences.getBoolean("ledStatus", false));
            Log.i("DrawerMenuAdapter:::::", swPreferences.getBoolean("ledStatus", false) + "");
        }

        return convertView;
    }

    public void addItem(String title, String type) {
        DrawerMenuItem item = new DrawerMenuItem();

        item.setTitle(title);
        if(type.equals("gps")) {
            item.setUseGPS(true);
        } else {
            item.setUseGPS(false);
        }
        if(type.equals("sw")) {
            item.setUseSW(true);
        } else {
            item.setUseSW(false);
        }
        arrayList.add(item);
    }
}
