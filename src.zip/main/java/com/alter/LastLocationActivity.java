package com.alter;

import android.app.FragmentManager;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class LastLocationActivity extends AppCompatActivity implements OnMapReadyCallback, View.OnClickListener{

    MapFragment map;
    ImageView img_back;
    TextView text_umbID, text_coordinate, text_time;

    FragmentManager fragmentManager;
    BluetoothApplication BT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_last_location);

        fragmentManager = getFragmentManager();
        BT = (BluetoothApplication)getApplicationContext();

        map = (MapFragment)fragmentManager.findFragmentById(R.id.map_lastLocation);
        img_back = findViewById(R.id.img_back);
        text_umbID = findViewById(R.id.text_umbID);
        text_coordinate = findViewById(R.id.text_umbCoordinate);
        text_time = findViewById(R.id.text_umbTime);

        map.getMapAsync(this);
        img_back.setOnClickListener(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        float lat,lng;
        String[] lastLocation = BT.getSharedData("lastLocation", "37.279956//127.008686").split("//");
        Log.i("test::::", BT.getSharedData("lastLocation", "37.279956//127.008686"));
        lat = Float.parseFloat(lastLocation[0]);
        lng = Float.parseFloat(lastLocation[1]);

        LatLng mapping = new LatLng(lat, lng);

        MarkerOptions makerOptions = new MarkerOptions();
        makerOptions.position(mapping);
        googleMap.addMarker(makerOptions);

        googleMap.moveCamera(CameraUpdateFactory.newLatLng(mapping));
        googleMap.animateCamera(CameraUpdateFactory.zoomTo(10));

        text_umbID.setText(BT.getSharedData("lastConnected", "NULL"));
        text_coordinate.setText(String.format("<%s, %s>", lastLocation[0], lastLocation[1].replaceAll("\n", "").replaceAll(" ", "")));
        text_time.setText(BT.getSharedData("lastReceive", "2999-12-31 99:99:99 . GMT+09:00"));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_back:
                startActivity(new Intent(this, MainActivity.class));
                finish();
                break;
        }
    }
}
