package com.alter;

public class DrawerMenuItem {
    String title;
    boolean isEnable, isUseSW, isUseGPS;

    public void setTitle(String title) {
        this.title = title;
    }

    public void setUseSW(boolean isUseSW) {
        this.isUseSW = isUseSW;
    }

    public void setUseGPS(boolean isUseGPS) {
        this.isUseGPS = isUseGPS;
    }

    public String getTitle() {
        return this.title;
    }

    public boolean getEnable() {
        return this.isEnable;
    }

}
