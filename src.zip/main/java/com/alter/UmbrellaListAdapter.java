package com.alter;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import java.util.ArrayList;

public class UmbrellaListAdapter extends BaseAdapter{

    SharedPreferences swPreferences;
    SharedPreferences.Editor swEditor;
    ArrayList<UmbrellaListItem> list = new ArrayList<>();

    BluetoothService btService;

    public UmbrellaListAdapter(SharedPreferences sharedPreferences, SharedPreferences.Editor editor, BluetoothApplication BT) {
        swPreferences = sharedPreferences;
        swEditor = editor;
        btService = BT.getBTService();
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {

        final Context context = parent.getContext();

        if(convertView == null) {
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.item_umbrella, parent, false);
        }

        TextView username = convertView.findViewById(R.id.item_kingsmanName);
        TextView status = convertView.findViewById(R.id.item_kingsmanStatus);
        final CheckBox selDevice = convertView.findViewById(R.id.item_selDevice);

        UmbrellaListItem item = list.get(position);

        username.setText(item.getUsername());

        selDevice.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                swEditor.putInt("checkPosition", position);
                swEditor.putBoolean("checkStatus", isChecked);
                swEditor.putString("lastConnected", list.get(position).getUsername());
                swEditor.putString("lastAddr", swPreferences.getString("deviceAddress"+position, ""));
                swEditor.commit();
                try {
                    if(isChecked) {
                        if(btService.isConnected != true) {
                            Log.i("try Connect", swPreferences.getString("deviceAddress" + position, ""));
                            btService.connectDevice(swPreferences.getString("deviceAddress" + position, ""));
                        }
                    } else {
                        if(btService.isConnected == true) {
                            btService.disconnectDevice();
                        }
                    }
                } catch (NullPointerException e) {
                    e.printStackTrace();
                }
                notifyDataSetChanged();
            }
        });
        try {
            list.get(swPreferences.getInt("checkPosition", 0)).setStatus(swPreferences.getBoolean("checkStatus", false));
        } catch (IndexOutOfBoundsException e) {

        }
        if(item.getStatus()) {
            status.setText("connected");
            status.setTextColor(Color.parseColor("#009cf1"));
            selDevice.setChecked(true);
        } else {
            status.setText("disconnected");
            status.setTextColor(Color.parseColor("#a7a7a7"));
            selDevice.setChecked(false);
        }

        return convertView;
    }

    public void addItem(String username) {
        UmbrellaListItem item = new UmbrellaListItem();
        item.setUsername(username);
        list.add(item);
    }

    public void clearList() {
        list.clear();
    }

    public void updateList() {
        notifyDataSetChanged();
    }

    public void changeName(String name) {
        UmbrellaListItem item = list.get(swPreferences.getInt("checkPosition", 1024));
        swEditor.putString("lastConnected", name);
        swEditor.putString("device"+swPreferences.getInt("checkPosition", 1024), name);
        swEditor.commit();
        item.setUsername(name);
    }
}
