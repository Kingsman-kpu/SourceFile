package com.alter;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class GETWeatherTask extends AsyncTask<String, String, String>{

    String apiKey = "dj0yJmk9djRhZG1OQm8yRkVEJmQ9WVdrOWFVWlhXR1JLTkdFbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD1kNw--";
    String apiUrl1 = "https://query.yahooapis.com/v1/public/yql?q=";
    String lineData, data;

    @Override
    protected String doInBackground(String... jsonData) {

        try {
            Log.i("GETWeatherTASK", jsonData[0]+ "/" +jsonData[1]);
            String YQL = Uri.encode(String.format("select * from weather.forecast where woeid in (select woeid from geo.places where text=\"(%s,%s)\") and u='c'", jsonData[0], jsonData[1]));
            URL url = new URL(apiUrl1 + YQL + "&format=json");
            HttpURLConnection connection = (HttpURLConnection)url.openConnection();

            if(connection.getResponseCode() == connection.HTTP_OK) {
                InputStreamReader input = new InputStreamReader(connection.getInputStream(), "UTF-8");
                BufferedReader buffer = new BufferedReader(input);
                StringBuffer data = new StringBuffer();
                while((lineData = buffer.readLine()) != null) {
                    data.append(lineData);
                }
                Log.i("JSONData::::", data.toString());
                this.data = data.toString();

                buffer.close();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }
}
