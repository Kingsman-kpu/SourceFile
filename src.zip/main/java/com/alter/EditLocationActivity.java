package com.alter;

import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;

public class EditLocationActivity extends AppCompatActivity {

    EditText edit_city;
    Button btn_editLocation;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_location);

        edit_city = findViewById(R.id.edit_city);
        btn_editLocation = findViewById(R.id.btn_editLocation);

        sharedPreferences = getSharedPreferences("pref", MODE_PRIVATE);
        editor = sharedPreferences.edit();

        btn_editLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeAddress(edit_city.getText().toString());
            }
        });
    }
    public void changeAddress(String address) {
        List<Address> addr = null;
        final Geocoder[] coder = {new Geocoder(this)};

        try {
            addr = coder[0].getFromLocationName(address, 1);
            final List<Address> finalAddr = addr;
            Runnable run = new Runnable() {
                @Override
                public void run() {
                    if(finalAddr.size() == 0) {
                        Toast.makeText(EditLocationActivity.this, "주소를 찾을 수 없습니다.", Toast.LENGTH_SHORT).show();
                        coder[0] = null;
                    }
                }
            };
            Handler h = new Handler();
            h.postDelayed(run, 3000);
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "주소를 찾을 수 없습니다.", Toast.LENGTH_SHORT).show();
        }
        if(addr != null) {
            for(int i=0;i<addr.size();i++) {
                Address latlan = addr.get(i);
                double lat = latlan.getLatitude();
                double lon = latlan.getLongitude();

                editor.putString("lat", String.valueOf(lat));
                editor.putString("lon", String.valueOf(lon));
                editor.putString("city", edit_city.getText().toString());
                editor.commit();

                Log.i("LOCATION:::::", "Latitude: " + lat + "Longitude: " + lon + "     CITY::::" + edit_city.getText().toString());

                startActivity(new Intent(this, MainActivity.class));
                finish();
            }
        } else {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
            Log.i("error", "error");
        }

    }
}
