package com.alter;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class GETWeatherIconTask extends AsyncTask<Bitmap, Bitmap, Bitmap>{

    String code;

    public GETWeatherIconTask(String code) {
        this.code = code;
    }

    @Override
    protected Bitmap doInBackground(Bitmap... bitmaps) {
        Bitmap icon = null;

        try{
            URL url = new URL(String.format("http://l.yimg.com/a/i/us/we/52/%s.gif", code));

            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
            conn.setDoInput(true);
            conn.connect();

            InputStream input = conn.getInputStream();
            icon = BitmapFactory.decodeStream(input);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return icon;
    }
}
