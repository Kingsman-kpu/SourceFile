package com.alter;

import android.app.ActivityManager;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class UmbrellaActivity extends AppCompatActivity implements View.OnClickListener{

    ImageView img_back;
    ListView list_umbrella;
    TextView text_nickname, text_editNickname;
    RelativeLayout layout_lastLocation;
    Button btn_pair;

    UmbrellaListAdapter umbrellaListAdapter;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    BluetoothAdapter btAdapter;
    BluetoothLeScanner bleScanner;
    BluetoothLeAdvertiser bleAdvertiser;
    BluetoothGattCharacteristic characteristic;
    ArrayList<String> item_device;
    AlertDialog.Builder alert_device;

    BluetoothService btService;
    BluetoothApplication BT;

    int BT_ENABLE = 1;
    String[] deviceInfo;
    String TAG = this.getClass().getSimpleName() + ":::::";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_umbrella);

        img_back = findViewById(R.id.img_back);
        list_umbrella = findViewById(R.id.list_umbrella);
        text_nickname = findViewById(R.id.text_nickname);
        text_editNickname = findViewById(R.id.text_nickEdit);
        layout_lastLocation = findViewById(R.id.layout_lastLocation);
        btn_pair = findViewById(R.id.btn_pair);

        BT = (BluetoothApplication)getApplicationContext();
        btService = BT.getBTService();
        sharedPreferences = getSharedPreferences("pref", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        umbrellaListAdapter = new UmbrellaListAdapter(sharedPreferences, editor, BT);
        btAdapter = BluetoothAdapter.getDefaultAdapter();
        bleScanner = btAdapter.getBluetoothLeScanner();
        bleAdvertiser = btAdapter.getBluetoothLeAdvertiser();

        img_back.setOnClickListener(this);
        text_editNickname.setOnClickListener(this);
        layout_lastLocation.setOnClickListener(this);
        btn_pair.setOnClickListener(this);
        list_umbrella.setAdapter(umbrellaListAdapter);
        text_nickname.setText(sharedPreferences.getString("lastConnected", "--"));

        refreshData();
    }

    public void addList() {
        int count = sharedPreferences.getInt("deviceCount", 0);
        for(int i=0;i<count;i++) {
            String deviceList = "device"+i;
            umbrellaListAdapter.addItem(sharedPreferences.getString(deviceList, "Unknown Device"));
        }
    }

    public void editNickName() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final EditText edit_nickname = new EditText(this);
        builder.setTitle("닉네임 설정");
        builder.setView(edit_nickname);
        builder.setPositiveButton("저장", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String nickname = edit_nickname.getText().toString();
                text_nickname.setText(nickname);
                btService.sendData("AT+NAME"+nickname);
                umbrellaListAdapter.changeName(nickname);
                umbrellaListAdapter.clearList();
                addList();
                umbrellaListAdapter.updateList();
                dialog.dismiss();
            }
        });
        builder.show();
    }

    public void newPair() {
        if(!btAdapter.isEnabled()) {
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), BT_ENABLE);
        } else {
            bleScanner.startScan(bleScanCallback);
            item_device = new ArrayList<>();
            alert_device = new AlertDialog.Builder(this);
            alert_device.setTitle("Select Device");
            alert_device.setCancelable(false);
            final ProgressDialog dialog = ProgressDialog.show(this, "", "Scanning Device...");
            dialog.show();
            Handler stopScan = new Handler();
            stopScan.postDelayed(new Runnable() {
                @Override
                public void run() {
                    bleScanner.stopScan(bleScanCallback);
                    dialog.dismiss();
                    Log.i(TAG, "stopScan");
                    item_device.add("test/192939192");
                    item_device.add("취소");
                    final CharSequence[] items = item_device.toArray(new CharSequence[item_device.size()]);
                    alert_device.setItems(items, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int position) {
                            if(item_device.get(position).equals("취소")) {
                                finish();
                            } else {
                                boolean alreadyDevice = false;
                                int deviceCount = sharedPreferences.getInt("deviceCount", 0);
                                Log.i(TAG, deviceCount + "");
                                deviceInfo = item_device.get(position).split("/");
                                for(int i=0;i<deviceCount;i++) {
                                    String deviceCheck = sharedPreferences.getString("device"+i, "");
                                    if(deviceCheck.contains(deviceInfo[0])) {
                                        alreadyDevice = true;
                                    }
                                    Log.i(TAG, "TEST!" + deviceCheck);
                                }
                                if(!alreadyDevice) {
                                    editor.putInt("deviceCount", deviceCount + 1);
                                    editor.putString("device" + deviceCount, deviceInfo[0]);
                                    editor.putString("deviceAddress" + deviceCount, deviceInfo[1]);
                                    editor.putInt("checkPosition", deviceCount);
                                    editor.putBoolean("checkStatus", true);
                                    editor.putBoolean("checkStatus", false);
                                    editor.putString("lastAddr", deviceInfo[1]);
                                    editor.putString("lastConnected", deviceInfo[0]);
                                    editor.commit();
                                    text_nickname.setText(deviceInfo[0]);
                                    btService.connectDevice(deviceInfo[1]);
                                    umbrellaListAdapter.clearList();
                                    addList();
                                    umbrellaListAdapter.updateList();
                                    Log.i(TAG, "Selected: " + deviceInfo[0]);
                                }
                            }
                        }
                    });
                    AlertDialog dialog = alert_device.create();
                    dialog.show();
                }
            }, 5000);
        }
    }

    public void refreshData() {
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        umbrellaListAdapter.clearList();
                        addList();
                        umbrellaListAdapter.updateList();
                    }
                });
            }
        }, 0, 2000);
    }

    ScanCallback bleScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            try {
                String deviceName = result.getDevice().getName();
                String deviceAddress = result.getDevice().getAddress();
                if((!deviceName.equals("null") || deviceName != null)) {
                    boolean overlap = false;
                    for(int i=0;i<item_device.size();i++) {
                        if((deviceName+"/"+deviceAddress).equals(item_device.get(i))) {
                            overlap = true;
                        }
                    }
                    if(overlap == false) {
                        item_device.add(deviceName + "/" + deviceAddress);
                    }
                }
            } catch (Exception e) {
                if(e.getClass() != NullPointerException.class) {
                    e.printStackTrace();
                }
            }
        }
    };

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_back:
                startActivity(new Intent(this, MainActivity.class));
                finish();
                break;
            case R.id.text_nickEdit:
                editNickName();
                break;
            case R.id.layout_lastLocation:
                startActivity(new Intent(this, LastLocationActivity.class));
                break;
            case R.id.btn_pair:
                newPair();
                break;
        }
    }
}
